package ie.ncirl.student.x15015556.dublinbuses;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;


public class WebViewActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newsshow);

        Bundle bundle = getIntent().getExtras();

        //Extract the data…
        String url = bundle.getString("url");

        WebView myWebView = (WebView) findViewById(R.id.webView1);
        myWebView.loadUrl(url);

        Button button_back = (Button) findViewById(R.id.button_back);
        button_back.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                finish();
            }
        });
    }
}
