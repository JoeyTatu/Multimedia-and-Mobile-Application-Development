package ie.ncirl.student.x15015556.dublinbuses;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    /*protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }*/


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(ie.ncirl.student.x15015556.dublinbuses.R.layout.activity_main);

        Button stopid = (Button)findViewById(R.id.buttonStopID);
        stopid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), StopIdActivity.class);
                view.getContext().startActivity(intent);}
        });


        Button routes = (Button)findViewById(R.id.button_route);
        routes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), RoutesActivity.class);
                view.getContext().startActivity(intent);}
        });


        Button address = (Button)findViewById(R.id.button_address);
        address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), RoutesActivity.class);
                view.getContext().startActivity(intent);}
        });

        Button nearby = (Button)findViewById(R.id.button_nearby);
        nearby.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), NearbyActivity.class);
                view.getContext().startActivity(intent);}
        });

        Button news = (Button)findViewById(R.id.button_news);
        news.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), NewsActivity.class);
                    view.getContext().startActivity(intent);}
        });
    }

//    public void launchStopIdActivity(View view){
//            //Log.d(LOG_TAG, "Button clicked");
//
////        Intent intent = new Intent(this, StopIdActivity.class);
////        startActivityForResult(intent, TEXT_REQUEST);
//    }

}


//}
