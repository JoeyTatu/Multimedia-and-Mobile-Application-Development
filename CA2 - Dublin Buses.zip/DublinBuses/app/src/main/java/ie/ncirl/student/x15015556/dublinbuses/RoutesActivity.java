package ie.ncirl.student.x15015556.dublinbuses;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

public class RoutesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(ie.ncirl.student.x15015556.dublinbuses.R.layout.activity_routes);

        Button button_Continue = (Button) findViewById(R.id.button_Continue);
        button_Continue.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                EditText input_number = (EditText)findViewById(R.id.editText_inputNumber);
                String number = input_number.getText().toString();
                String url = "https://www.dublinbus.ie/RTPI/Sources-of-Real-Time-Information/?searchtype=route&searchquery=" + number;

                Intent i = new Intent(getApplicationContext(), WebViewActivity.class);

                //Create the bundle
                Bundle bundle = new Bundle();

                //Add your data to bundle
                bundle.putString("url", url);

                //Add the bundle to the intent
                i.putExtras(bundle);

                //Fire that second activity
                startActivity(i);
            }
        });

        Button button_menu = (Button) findViewById(R.id.button_back);
        button_menu.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                finish();
            }
        });
    }
}

